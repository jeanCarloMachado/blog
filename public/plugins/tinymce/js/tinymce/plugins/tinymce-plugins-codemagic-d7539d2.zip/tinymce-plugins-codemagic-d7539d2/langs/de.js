tinyMCE.addI18n('de.codemagic', {
    editor_button: "HTML Quelltext bearbeiten"
});
