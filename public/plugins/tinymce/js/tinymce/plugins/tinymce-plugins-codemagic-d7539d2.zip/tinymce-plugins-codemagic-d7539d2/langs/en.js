tinyMCE.addI18n('en.codemagic', {
    editor_button: "Edit source code"
});
