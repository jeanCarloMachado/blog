tinyMCE.addI18n('cs.codemagic', {
    editor_button: "Upravit HTML kód"
});
