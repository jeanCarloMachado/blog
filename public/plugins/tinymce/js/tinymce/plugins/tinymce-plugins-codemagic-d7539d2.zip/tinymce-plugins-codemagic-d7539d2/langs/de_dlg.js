tinyMCE.addI18n('de.codemagic_dlg', {
    code_title: "CodeMagic - Syntax Hervorhebung und Einzug",
    code_label: "HTML Code bearbeiten",
    toggle_highlighting: "Syntax Hervorhebung",
    toggle_autocompletion: "Auto Vervollst&auml;ndigen",
    toggle_wraptext: "Umbrechen von Text",
    search: "Suchen",
    replace: "Ersetzen",
    undo: "R&uuml;ckg&auml;ngig",
    redo: "Wiederherstellen",
    search_replace: "Suchen und Ersetzen",
    reintendt: "HTML Code formatieren",
    nothing_found: "Nichts gefunden.",
    nothing_to_replace: "Nichts zu ersetzen."
});
