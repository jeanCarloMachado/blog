tinyMCE.addI18n('fr.codemagic', {
    editor_button: "Modifier code source"
});
