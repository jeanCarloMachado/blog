tinyMCE.addI18n('sk.codemagic', {
    editor_button: "Upraviť HTML kód"
});
