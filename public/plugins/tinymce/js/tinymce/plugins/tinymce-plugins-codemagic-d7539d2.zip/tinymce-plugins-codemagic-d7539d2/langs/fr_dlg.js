tinyMCE.addI18n('fr.codemagic_dlg', {
    code_title: "CodeMagic - coloration syntaxique et indentation",
    code_label: "Modifier Code",
    toggle_highlighting: "Coloration syntaxique",
    toggle_autocompletion: "Auto completion",
    toggle_wraptext: "Envelopper le texte",
    search: "Recherche",
    replace: "Renplace",
    undo: "Annuler",
    redo: "Refaire",
    search_replace: "Rechercher et remplacer",
    reintendt: "Formater code HTML",
    nothing_found: "Rien trouv&eacute;.",
    nothing_to_replace: "Rien &agrave; remplacer."
});
